# Software Quality Insight — Practice Dataset

This is a **synthetic educational dataset** created for Use Case 28: Software Quality Insight. It is not real company data and should not be presented as measured findings from CodeMetric Software Labs.

## Files
- `modules.csv`: module catalogue (`module`, `component`, `language`, `size`)
- `metrics.csv`: module-release software metrics (`module`, `release`, `complexity`, `coupling`, `churn`, `test_coverage`)
- `defects.csv`: defect counts and severity per module-release (`module`, `release`, `defect_count`, `severity`)
- `commits.csv`: commit activity per module-release (`module`, `release`, `commit_count`, `contributors`, `changed_lines`)
- `releases.csv`: release date and version per module (`module`, `version`, `release_date`)

## Join keys
Use normalized `module` names plus release version as the analysis key. In `metrics.csv`, `defects.csv`, and `commits.csv`, the release column corresponds to `releases.csv`'s `version` column.

## Intentional data-quality cases for the assessment
- Missing metric values in `metrics.csv`
- Duplicate `AUTH` / `v1.0` row in `metrics.csv`
- Inconsistent module name (`Payment` rather than `PAY`) in `metrics.csv`
- Extreme complexity value (`185`) for `PAY` / `v3.0`
- Unmatched defect row for `LEGACYMOD` / `v3.0`

## Suggested workflow
1. Load all five CSV files with pandas.
2. Normalize module names and validate module-release keys.
3. Investigate missing values, duplicates, and outliers before deciding how to treat them.
4. Join on module + release/version and document unmatched records.
5. Analyze defects against complexity, coupling, churn, coverage, commit count, and contributors.

Because the data is synthetic, model metrics and insights should be calculated from the cleaned dataset you actually create. Do not copy illustrative model scores unless you have run the model.
